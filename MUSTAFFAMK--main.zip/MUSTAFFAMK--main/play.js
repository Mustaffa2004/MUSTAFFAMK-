//Fuck You Buy Ibradam Adams//
